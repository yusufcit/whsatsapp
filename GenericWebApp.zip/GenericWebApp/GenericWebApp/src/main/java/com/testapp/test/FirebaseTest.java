package com.testapp.test;

import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import com.testapp.test.pages.FrameworkTestBase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class FirebaseTest extends FrameworkTestBase {

    private static final Logger logger = LogManager.getLogger(FirebaseTest.class);
    static Firestore db = null;

    public void settingFirebase(){
        try {
            InputStream serviceAccount = new FileInputStream("src/test/resources/dbconnect.json");
            GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount);
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setCredentials(credentials)
                    .build();
            FirebaseApp.initializeApp(options);
            db = FirestoreClient.getFirestore();
            logger.info("Firebase setup - Done");
        }
        catch (Exception e){
            logger.info("Failed to connect to Firebase");
        }
    }

    /**
     * This method writes data to Firebase Database
     * @param storeName  It is the collection name on Fribase. (e.g. Lidl)  It should be Enum type parameter, to stop people passing any type of string
     * @param itemName   It is the Document name in Friebase. Name of the product (e.g. orange), it's a string parameter
     * @param itemDetails  It is the field value in Firebase. (e.g. imgUrl, price, startDate, endDate), it's a HashMap collection.
     */
    public void writeData(String storeName, String itemName, HashMap itemDetails){

        try {
            DocumentReference docRef = db.collection(storeName).document(itemName);
            System.out.println(docRef.toString());
            ApiFuture<WriteResult> result = docRef.set(itemDetails);
// result.get() blocks on response
            System.out.println("Update time : " + result.get().getUpdateTime());
        }
        catch (Exception e){
            System.out.println("Failed to write to database");
        }

    }

    public void readData() {

        try {
            // asynchronously retrieve all users
            ApiFuture<QuerySnapshot> query = db.collection("users").get();
// ...
// query.get() blocks on response
            QuerySnapshot querySnapshot = query.get();
            List<QueryDocumentSnapshot> documents = querySnapshot.getDocuments();
            System.out.println("printing documents -=============");

            for (QueryDocumentSnapshot document : documents) {
                System.out.println("Document info--------------");
                System.out.println(document.getData().toString());
                System.out.println("User: " + document.getId());
                System.out.println("First: " + document.getString("first"));
                if (document.contains("middle")) {
                    System.out.println("Middle: " + document.getString("middle"));
                }
                System.out.println("Last: " + document.getString("last"));
                System.out.println("Born: " + document.getLong("born"));
        }


        }
        catch (Exception e){
            System.out.println("Failed to read data");
        }
    }

}
