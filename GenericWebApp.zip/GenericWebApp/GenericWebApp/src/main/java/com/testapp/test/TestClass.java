package com.testapp.test;

import java.lang.reflect.Array;
import java.util.*;

public class TestClass {
    public static void main(String[] args){

        getTwoNumbers();
    }




    public static void getTwoNumbers() {

        HashMap<Integer, String> idAndName = new HashMap<Integer, String>();

        Hashtable mytable = new Hashtable();
        mytable.put("abc", "kkk");

        idAndName.put(101, "Abdullah");
        idAndName.put(102, "Abdur Rahman");
        idAndName.put(103, "Abdul Aziz");
        idAndName.put(104, "Abdul Khalik");
        idAndName.put(105, "Omar");

        for (int a : idAndName.keySet()){
            if (idAndName.get(a).equals("Omar"))
                idAndName.remove(a);

//            System.out.println(idAndName.get(a));

        }

        for (int a : idAndName.keySet()){

            System.out.println(idAndName.get(a));

        }


    }



}
