package com.testapp.test.pages;

import com.testapp.test.DefaultDriver;
import com.testapp.test.WaitTime;
import org.openqa.selenium.By;

import static com.testapp.test.pages.FrameworkTestBase.logger;

public class HomePage extends FrameworkTestBase {
    public HomePage(DefaultDriver driverRef){
        this.driver=driverRef;
    }

    private static final By loginLink = By.xpath("//*[@id=\"header\"]/div/div/div/div[3]/a[4]/span[2]");


    public void clickOnLogInLink() {
        logger.info("Clicking on signin link");
        driver.click(loginLink);
        driver.sleep(WaitTime.XSMALL_WAIT);
        driver.getAttributeValue("style", loginLink);
    }



}
