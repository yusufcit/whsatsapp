package com.testapp.test.pages;

import com.testapp.test.DefaultDriver;

public class SignInPage extends FrameworkTestBase {

    public SignInPage(DefaultDriver driverRef){
        this.driver=driverRef;
    }

    public void enterEmailAddress(String emailAddress){

    }

    public void enterPassword(String password){

    }

}
