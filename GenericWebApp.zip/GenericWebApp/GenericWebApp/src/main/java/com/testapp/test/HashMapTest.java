package com.testapp.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class HashMapTest {

    public static void main(String[] args) {

        HashSet<String> cars = new HashSet<>();

        cars.add("cad");

        List<Integer> list = new ArrayList<Integer>();

        list.add(100);
        list.add(10);
        System.out.println("average is: " + average(list));;

    }

    public static Double average(List<Integer> list) {
        int sm = list.stream()
                .mapToInt(i->i)
                .sum();

        System.out.println("Sum is: " + sm);

        return list.stream()
                .mapToInt(i -> i)
                .average()
                .getAsDouble();
    }

}
