package com.testapp.test;

import com.testapp.test.pages.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;

public class LandingPageTest extends FrameworkTestBase {

//    @Test
//    public static void currysLoginTest() {
//        logger.info("Starting Currys Login Test");
//        CurrysLandingPage landingPage = new CurrysLandingPage(driver);
//        SignInOrRegister signInOrRegister = new SignInOrRegister(driver);
//        SignInPage signInPage = new SignInPage(driver);
//
//        landingPage.clickOnAcceptCookies();
//        landingPage.clickOnSignInLink();
//        signInOrRegister.enterEmailAddress("faruk@gmail.com");
//        signInOrRegister.selectHaveAccount();
//        signInOrRegister.enterPassword("abcd1234?");
//
////        signInOrRegister.clickSigninButton();
//        signInPage.enterEmailAddress("faruk@gmail.com");
//        signInPage.enterPassword("abcd1234?");
//
//    }
//
//    @Test
//    public static void currysRegisterTest() {
//        logger.info("Starting Currys Login Test");
//        CurrysLandingPage landingPage = new CurrysLandingPage(driver);
//        SignInOrRegister signInOrRegister = new SignInOrRegister(driver);
//        SignInPage signInPage = new SignInPage(driver);
//
//        landingPage.clickOnAcceptCookies();
//        landingPage.clickOnSignInLink();
//        signInOrRegister.enterEmailAddress("faruk@gmail.com");
//        signInOrRegister.selectHaveAccount();
//        signInOrRegister.enterPassword("abcd1234?");
////        signInOrRegister.clickSigninButton();
//        signInPage.enterEmailAddress("faruk@gmail.com");
//        signInPage.enterPassword("abcd1234?");
//
//
//    }

    @Test
    public static void supervalueProducts(){
        System.out.println("Working Directory = " + System.getProperty("user.dir"));

        driver.sleep(WaitTime.MEDIUM_WAIT);
        driver.sleep(WaitTime.MEDIUM_WAIT);
        driver.sleep(WaitTime.MEDIUM_WAIT);
        driver.sleep(WaitTime.MEDIUM_WAIT);
        driver.sleep(WaitTime.MEDIUM_WAIT);


        driver.click(By.cssSelector("span[data-icon='clip']"));

        driver.sendKeys(By.cssSelector("input[type='file']"), System.getProperty("user.dir") + "/src/test/resources/myimage.jpeg");
        driver.sleep(WaitTime.MEDIUM_WAIT);

//click to send
        driver.click(By.cssSelector("span[data-testid=\"send\"]"));

        driver.sleep(WaitTime.MEDIUM_WAIT);
        driver.sleep(WaitTime.MEDIUM_WAIT);



//        String itemName = "Orange";
//        HashMap<String, Object> itemDetails = new HashMap<String, Object>();
//        itemDetails.put("price", 0.23);
//        itemDetails.put("imgUrl", "lidle.com");
//        itemDetails.put("startDate", "13/05/2022");
//        itemDetails.put("EndDate", "23/05/2022");
//
//
//        driver.writeData(StoreName.ALDI.getName(), itemName, itemDetails);

    }


}
