package com.testapp.test;

public class AdvertsLandingPage {
}
