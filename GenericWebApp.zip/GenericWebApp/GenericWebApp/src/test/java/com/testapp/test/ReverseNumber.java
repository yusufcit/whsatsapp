package com.testapp.test;

public class ReverseNumber {
    public long reverse(long num)
    {
        long temp=0;
        while(num!=0)
        {
            temp=(temp*10)+(num%10);
            System.out.println("temp value is: " + temp);
            num=num/10;
            System.out.println("Num value is: " + num);
        }
        return temp;
    }
    public static void main(String args[])
    {
        long n= 342619;
        ReverseNumber inp = new ReverseNumber();
        System.out.println("Given number is "+ n);
        System.out.println("Reverse of given number is "+inp.reverse(n));
    }
}
