package com.testapp.test;

import java.util.ArrayList;
import java.util.List;

public class Notepad {
    public static void main(String[] args){
        int n=15;
        int finalSum = 0;

        for (int i=0; i<=n; i++){
            if ((i%3==0) || (i%5 == 0)) {
                System.out.println(i);
                finalSum += i;
            }
        }

        System.out.println(finalSum);

        // Creating object of ArrayList class
        List<Integer> list = new ArrayList<Integer>();

        // Populating List by adding integer elements
        // using add() method
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);


        // Printing elements of List
        System.out.println("Before operation: " + list);

        // Getting total size of list
        // using size() method
        int size = list.size();

        for (int i=0; i<list.size(); i++) {
            if (list.get(i) == 1) {}
        }

        // Printing the size of List
        System.out.println("Size of list = " + size);

        // String reversed
        String s = "java interview";
        String reversed = "";
        System.out.println(s.length());
        for(int i=s.length()-1; i>=0; i--) {
            reversed = reversed+s.charAt(i);
        }

        System.out.println(reversed);

        // largest int

        ArrayList<Integer> list1 = new ArrayList<Integer>();
        list1.add(2);
        list1.add(33);
        list1.add(5);
        list1.add(6);
        list1.add(9);

        System.out.println(maximum(list1));



    }

    public static Integer maximum(List<Integer> list) {
        int largst = 0;

        for(int i: list){
            if(i > largst)
                largst=i;
        }

        return largst;

    }
}
