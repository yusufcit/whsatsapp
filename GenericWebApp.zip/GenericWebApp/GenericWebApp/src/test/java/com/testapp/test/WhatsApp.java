package com.testapp.test;

import com.testapp.test.pages.FrameworkTestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class WhatsApp extends FrameworkTestBase {
    boolean isFirstTime = true;

    @Test
    public void sendMessage(){
        try {
            String Fpath = System.getProperty("user.dir") + "/src/test/resources/contacts.csv";
            String line;
            File file = new File(Fpath);

            BufferedReader bufRdr;
            bufRdr = new BufferedReader(new FileReader(file));

            while((line = bufRdr.readLine()) != null){
                String url = "https://web.whatsapp.com/send?phone=PHONENUMBER&text= " +
                        "আস সালামু আলাইকুম, NAME %0A" +
                        "আমার শুভেচ্ছা গ্রহণ করুন। আগামীকাল আবাই নির্বাচনে আপনার ভোটাধিকার প্রয়োগ করুন। আমি এই নির্বাচনে সভাপতি পদপ্রার্থী। আমাকে যদি যোগ্যতর ব্যাক্তি হিসেবে বিবেচনা করেন তাহলে আপনার মূল্যবান ভোট দিয়ে বাধিত করবেন। \n" +
                        "\n" +
                        "আপনার দোয়া, সহযোগিতা এবং সমর্থন কামনা করছি।  শুভেচ্ছান্তে- ডাঃ জিন্নুরাইন জায়গীরদার।  %0A" +
                        "%0A আপনার ভোটার আইডি নম্বর : VOTERID";

                String[] cell= line.split(",");
                String FirstName=cell[1];
                String phoneNumber=cell[3];
                String voterId=cell[0];
                phoneNumber = phoneNumber.replaceAll("\\s+","").replaceAll("\\+", "").
                        replaceAll("^08", "3538").replaceAll("^8", "3538").
                        replaceAll("\\(", "").replaceAll("\\)", "");
                if (phoneNumber.length() == 12 ) {
                    System.out.println("Sending message to" + FirstName);
                    System.out.println("phone number : " + phoneNumber);
                    url = url.replaceAll("PHONENUMBER", phoneNumber);
                    url = url.replaceAll("NAME", FirstName);
                    url = url.replaceAll("VOTERID", voterId);
                    try {
                        sendText(url);
                    }
                    catch (Exception e){
                        System.out.println("Following number doesn't have whatsapp: " + phoneNumber);
                    }

                }
                else {
                    System.out.println("Number format is wrong: " + phoneNumber);
                }
            }
        }
        catch (Exception e){
            logger.error("Filed to read file");
        }
    }

    public void sendText(String url){
        //else driver.sleep(WaitTime.SMALL_WAIT);
        driver.openURL(url);
        if (isFirstTime) {
            driver.sleep(WaitTime.LONG_WAIT);
            driver.sleep(WaitTime.SMALL_WAIT);
        }
        driver.sleep(WaitTime.XSMALL_WAIT);

        //Click on attach icon
        driver.click(By.cssSelector("span[data-icon='clip']"));

        //attach the file
        driver.sendKeys(By.cssSelector("input[type='file']"), System.getProperty("user.dir") + "/src/test/resources/myimage.jpeg");
        driver.sleep(WaitTime.SMALL_WAIT);

        //click to send
        driver.click(By.cssSelector("span[data-testid=\"send\"]"));
        driver.sleep(WaitTime.MEDIUM_WAIT);
        isFirstTime = false;
    }

}

