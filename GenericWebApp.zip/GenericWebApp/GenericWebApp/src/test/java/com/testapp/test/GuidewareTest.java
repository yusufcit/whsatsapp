package com.testapp.test;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GuidewareTest {

    public static void main(String[] args) {
        boolean matchFound = matchPatter("");
        if(matchFound) {
            System.out.println("Match found");
        } else {
            System.out.println("Match not found");
        }
    }

    static boolean matchPatter(String arg) {
        if (arg.isEmpty()){
            return false;
        }
        else {
            Pattern pattern = Pattern.compile("b+a+");
            Matcher matcher = pattern.matcher(arg);
            boolean matchFound = matcher.find();
            return  matchFound;
        }
    }
}
