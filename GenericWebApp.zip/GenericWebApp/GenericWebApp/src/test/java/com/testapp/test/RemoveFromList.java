package com.testapp.test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class RemoveFromList {
    // Generic method to remove elements from a list in Java
    public static <T> void filterList(List<T> list, Predicate<T> condition)
    {
        for (int i = 0; i < list.size(); i++)
        {
            if (condition.test(list.get(i)))
            {
                list.remove(i);
                i--;
            }
        }
    }

    public static void main(String[] args)
    {
        List<String> colors = new ArrayList<>(Arrays.asList("BLUE", "RED", "RED", "YELLOW"));

        filterList(colors, i -> i.equals("RED"));
        System.out.println(colors);   // [BLUE, YELLOW]
    }
}
