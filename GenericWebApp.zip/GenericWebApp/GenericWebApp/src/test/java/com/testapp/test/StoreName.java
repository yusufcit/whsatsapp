package com.testapp.test;

 public enum StoreName {
     LIDL("Lidl"),
     ALDI("Aldi"),
     SUPERVALUE("Supervalue"),
     MORISON("Morison");

     public String name;

     StoreName(String name) {

         this.name = name;
     }

     public String getName() {
         return name;
     }
}
