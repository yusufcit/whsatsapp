package com.testapp.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;


class Solution2 {
    public static void main(String[] args) {
        ArrayList<String> strings = new ArrayList<String>();
        strings.add("01-28-2022,popcorn");
         strings.add("01-28-2022,popcorn");
         strings.add("01-28-2022,soda");
         strings.add("02-28-2022,soda");
         strings.add("02-28-2022,soda");
        strings.add("02-28-2022,popcorn");

        getPrice(strings);
    }

    public static double getPrice(ArrayList<String> items){

        double totalPrice=0.0;
        double[] prices = new double[items.size()];


            for (int i = 0; i < items.size(); i++) {
                if (prices[i]==0.0) {
                String date = items.get(i).split(",")[0];
                String product = items.get(i).split(",")[1];

                for (int j = i + 1; j < items.size(); j++) {
                    String nextItem = items.get(j);
                    if (date.equals(nextItem.split(",")[0]) &&
                            !product.equals(nextItem.split(",")[1])
                            && prices[j] == 0.0) {
                        System.out.println("Adding following prices: " + product + " and " + nextItem.split(",")[1] );
                        System.out.println("value of i: " + i + " Value of J: " + j);
                        prices[j] = 5;
                        prices[i] = 5;
                        break;
                    }
                }

                if (prices[i] == 0) {
                    System.out.println("setting the price for: " + items.get(i));
                    System.out.println("value of i: " + i);
                    prices[i] = getCost(product);
                }
            }
        }

        totalPrice = Arrays.stream(prices).sum();
        System.out.println("total Price is: =============== " + totalPrice);
        return totalPrice;

    }

    public static double getCost(String item) {
        switch(item) {
            case "popcorn":
                return 7.00;
            case "soda":
                return 5.00;
            case "bundle":
                return 10.00;
            default:
                return 0.0;

        }
    }
}


