package com.testapp.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class SOS {
    public static void main(String args[]){
        String message = "SOWSOT";
        System.out.println(marsExploration(message));
        List<Integer> myNumbers = new ArrayList<Integer>();

        myNumbers.add(3);
        myNumbers.add(4);
        myNumbers.add(1);
        myNumbers.add(2);
        myNumbers.add(4);
        birthdayCakeCandles(myNumbers);

        System.out.println(timeConversion("08:40:20PM"));
    }

    public static int marsExploration(String s) {
        // Write your code here
        String sosString = "";
        if(s.length()>0)
            for(int i=0; i<s.length()/3; i++)
            {
                sosString+= "SOS";
            }
        System.out.println(sosString);
        int numReplace = 0;

        for(int i=0; i<s.length(); i++)
        {
            if(sosString.charAt(i) != s.charAt(i))
                numReplace+=1;
        }

        return numReplace;


    }
    public static void birthdayCakeCandles(List<Integer> candles) {
        // Write your code here
        int maxNum = candles.stream().mapToInt(v -> v).max().getAsInt();
        System.out.println(Collections.frequency(candles, maxNum));

    }

    public static String timeConversion(String s) {
        // Write your code here
        SimpleDateFormat displayFormat = new SimpleDateFormat("HH:mm:ss");
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ssa");
        Date date = null;

        try{
            date = sdf.parse(s);
        }
        catch(ParseException e) {
            e.toString();
        }

        return displayFormat.format(date);
    }
}
