package com.testapp.test;

import java.awt.*;
import java.lang.reflect.Array;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Stream {
    public static void main(String args[]) {
        int[] array = new int[10];
        Random rand = new Random();

        for (int i = 0; i < array.length; i++)
            array[i] = rand.nextInt(100) + 1;

        find(array);
    }
    public static void find (int[] array){
        Arrays.sort(array);
        System.out.println(array[array.length - 2]);
    }
}

