package com.testapp.test;

public class FilterTest {
    public static void main(String args[]) {
        System.out.println(StoreName.SUPERVALUE.getName());
    }
}
