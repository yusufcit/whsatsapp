package com.testapp.test;

import com.testapp.test.pages.*;
import org.testng.annotations.Test;

public class AdsTest extends FrameworkTestBase {

    @Test
    public static void loginTest() {

        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);

        homePage.clickOnLogInLink();
        loginPage.EnterEmailAddress();
//        loginPage.EnterPacssword();
        loginPage.ClickLoginButton();
    }

    @Test
    public static void RegistrationTest() {

        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);

        homePage.clickOnLogInLink();
        loginPage.EnterEmailAddress();
        loginPage.EnterPassword();
        loginPage.ClickLoginButton();
    }

}
