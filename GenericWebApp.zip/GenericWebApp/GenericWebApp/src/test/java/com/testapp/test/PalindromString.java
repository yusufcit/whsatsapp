package com.testapp.test;

public class PalindromString {
    public static void main(String[] args){
        String test = "abaaabbaa";
        String longestPalindrom = "";

//        StringBuffer reversed = new StringBuffer(test);
//        reversed = reversed.reverse();
//        System.out.println(reversed.toString());
//
//        if (test.equals(reversed.toString()))
//            System.out.println("It is a palindrom");
//        else System.out.println("It is not a palindrom");

        for (int i=0; i<test.length(); i++){
            for (int j=i; j<test.length(); j++){
                if (isPalindrom(test.substring(i, j))){
//                    System.out.println(test.substring(i, j));
                    if (test.substring(i, j).length() > longestPalindrom.length())
                        longestPalindrom = test.substring(i, j);
                }

            }
        }

        System.out.println(longestPalindrom);
    }

    public static boolean isPalindrom(String s){
        StringBuffer rev = new StringBuffer(s);
        return  (s.equals(rev.reverse().toString()));

    }
}
